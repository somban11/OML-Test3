# KhmerStock Online — One‑Click Deploy (Render.com)

This package deploys **NocoDB** on **Render.com** with a free managed PostgreSQL database.
You'll get an online URL like `https://khmerstock-online.onrender.com` to run your inventory system.

## Deploy (3–5 minutes)
1. Create a new GitHub repository (empty is fine).
2. Upload these files to the repo (`Dockerfile`, `render.yaml`, `README.md`).
3. Go to https://render.com → **New** → **Blueprint** → Connect your GitHub repo.
4. Click **Deploy**. Render will automatically:
   - Provision a free PostgreSQL DB (`khmerstock-db`)
   - Build & run NocoDB as a **Web Service**
   - Inject `NC_DB_URL` into the service
5. When it turns **Live**, click your web URL → finish NocoDB setup.

## Default settings
- NocoDB listens on port **8080** inside the container (Render maps it to `$PORT`).
- Environment variables set by `render.yaml`:
  - `NC_DB=pg`
  - `NC_DB_URL=<render managed postgres connection string>`
  - `NC_PUBLIC_URL=https://khmerstock-online.onrender.com` (you can change it later)

## After first login
1. Create a project: `InventorySystem`
2. Create tables or import CSV templates (Products, Users, Sales)
3. Add a **Formula** column in `Products` named `RemainingStock`:
   ```
   StockQty - SUM(Sales.Qty WHERE Sales.ProductSKU = Products.SKU)
   ```
4. Create **Roles**: `Admin` and `Reseller`, restrict delete permissions.
5. Add Views for Resellers (hide cost, allow "Add Sale").

## Notes
- Free plans sleep on inactivity; upgrade if you need 24/7.
- For Khmer/English UI labels, customize in NocoDB UI.
- Back up regularly: export CSV or connect to external backup.

---
**Made for: KhmerStock simple & affordable setup.**
